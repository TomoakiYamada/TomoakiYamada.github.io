These are Fortran code used in
"Income Risk, Macroeconomic and Demographic Change, and Economic Inequality in Japan,"
Journal of Economic Dynamics and Control, Vol. 36, pp. 63-84, 2012,
by Tomoaki YAMADA

The zip file contains four folders, in which Fortran codes "XX.f90" and "YY.in" files are contained.
The "YY.in" files are inputs for computation.

I have compute all results using Fortran 90/95 with Intel Visual Fortran compiler.
You need to have IMSL and numerical recipes (nrtype.f90, nr.f90, nrutil.f90) to run the program.

Calibration: This project is used to find calibrated parameters that minimizes the residual of the variance of logarithm profiles.
            See Section 4.2.

SteadyState: Find equilibrium factor prices in a steady state.

Transition: This is main file to compute transition paths. Outputs are used in Figure 4-7.

Mis-prediction: This project is used to compute results shown in Figure 8. Section 5.8

